﻿

namespace ConsoleApp1
{
    class MathFunctions
    {
        public static double GetZero()
        {
            return 0;
        }

        public static double Add(double x, double y)
        {
            // y = f(x1, x2) = x1 + x2

            return x + y;
        }

        public static double Subtruct(double x, double y)
        {
            return x - y;
        }
    }
}
